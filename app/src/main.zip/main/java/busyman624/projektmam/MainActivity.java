package busyman624.projektmam;

import android.app.Activity;
import android.content.Context;
import android.graphics.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.RelativeLayout;
import android.widget.Toast;


public class MainActivity extends Activity implements SensorEventListener{
    /** Called when the activity is first created. */

    RelativeLayout rl;
    SensorManager sm;
    CameraView myCameraOverlay;
    Preview myCameraView;
    float[] mGravs = new float[3];
    float[] mGeoMags = new float[3];
    float[] rotFromBtoM = new float[9];
    float[] cameraM = new float[3];
    float[] cameraB = new float[3];
    float[] DBpoint = new float[4];
    static Context context;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rl = (RelativeLayout)findViewById(R.id.relativeLayout1);
        myCameraView = new Preview(this);
        rl.addView(myCameraView);
        myCameraOverlay = new CameraView(this);
        rl.addView(myCameraOverlay);
        cameraB[0] = 0;
        cameraB[1] = 0;
        cameraB[2] = -1;
        DBpoint[0] = (54.357013f * 3.14f) / 180.0f;
        DBpoint[1] = (18.590714f * 3.14f) / 180.0f;
        DBpoint[2] = (54.355270f * 3.14f) / 180.0f;
        DBpoint[3] = (18.609206f * 3.14f) / 180.0f;

        sm = (SensorManager)getSystemService(SENSOR_SERVICE);
        context=this;
    }

    @Override
    protected void onPause() {
        super.onPause();
        sm.unregisterListener(this);
        sm.unregisterListener(sensorEventListener);
        //Toast.makeText(this, "KameraAugmentedActivity.onPause()\nunregisterListener", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Sensor def = sm.getDefaultSensor(Sensor.TYPE_ALL);
        sm.registerListener(this, def, SensorManager.SENSOR_DELAY_NORMAL);
        sm.registerListener(sensorEventListener, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
        sm.registerListener(sensorEventListener, sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD), SensorManager.SENSOR_DELAY_NORMAL);
        sm.registerListener(sensorEventListener, sm.getDefaultSensor(Sensor.TYPE_ORIENTATION), SensorManager.SENSOR_DELAY_NORMAL);
        //Toast.makeText(this, "KameraAugmentedActivity.onResume()\nregisterListener", Toast.LENGTH_LONG).show();
    }

    //Nadpisane z SensorEventListener
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        myCameraOverlay.setDane(event.values);
        myCameraView.invalidate();
    }

    private SensorEventListener sensorEventListener = new SensorEventListener() {

        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }

        public void onSensorChanged(SensorEvent event) {
            switch (event.sensor.getType()) {
                case Sensor.TYPE_ACCELEROMETER:
                    //System.arraycopy(event.values, 0, mGravs, 0, 3);
                    mGravs = event.values.clone();
                    break;
                case Sensor.TYPE_MAGNETIC_FIELD:
                    //System.arraycopy(event.values, 0, mGeoMags, 0, 3);
                    mGeoMags = event.values.clone();
                    break;
                default:
                    return;
            }

            if (mGravs != null && mGeoMags != null) {
                // checks that the rotation matrix is found
                boolean success = SensorManager.getRotationMatrix(rotFromBtoM, null, mGravs, mGeoMags);
                if(success) {
                    cameraM[0] = cameraB[0] * rotFromBtoM[0] +
                            cameraB[1] * rotFromBtoM[1] +
                            cameraB[2] * rotFromBtoM[2];
                    cameraM[1] = cameraB[0] * rotFromBtoM[0 + 3] +
                            cameraB[1] * rotFromBtoM[1 + 3] +
                            cameraB[2] * rotFromBtoM[2 + 3];
                    cameraM[2] = cameraB[0] * rotFromBtoM[0 + 6] +
                            cameraB[1] * rotFromBtoM[1 + 6] +
                            cameraB[2] * rotFromBtoM[2 + 6];

                    float[] MframePoint = latlonToENU(DBpoint[0], DBpoint[1], 70 , DBpoint[2], DBpoint[3], 70);
                    double angle = getAngle(MframePoint, cameraM);
                    angle = (angle * 180.0f) / 3.14f;

                    if(angle < 10 && angle > -10)
                        Log.d("myTag", "" + angle);
                }
            }
        }
    };

    double getAngle(float[] a, float b[]) {
        double temp = (a[0] * b[0] + a[1] * b[1] + a[2] * b[2]) /
                Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]) /
                Math.sqrt(b[0] * b[0] + b[1] * b[1] + b[2] * b[2]);
        return Math.acos(temp);
    }

    static final float EARTH_RADIUS = 6378137;
    //lat – szerokość i lon – długość geograficzna w radianach
    static float[] latLonToECEF(float lat,float lon,float height){
        float[] ECEF = new float[3];
        ECEF[0]=(float)((height+ EARTH_RADIUS)*Math.cos(lat)*Math.cos(lon));
        ECEF[1]=(float)((height+ EARTH_RADIUS)*Math.cos(lat)*Math.sin(lon));
        ECEF[2]=(float)((height+ EARTH_RADIUS)*Math.sin(lat));
        return ECEF;
    }

    static float[] latlonToENU(float xLat,float xLon,float xHeight,
                               float uLat,float uLon,float uHeight){
        float[] ecefX=latLonToECEF(xLat,xLon,xHeight);
        float[] ecefU=latLonToECEF(uLat,uLon,uHeight);
        float[] offsetECEF = new float[3];
        offsetECEF[0]=ecefX[0]-ecefU[0];
        offsetECEF[1]=ecefX[1]-ecefU[1];
        offsetECEF[2]=ecefX[2]-ecefU[2];
        float[] enu = new float[3];
        enu[0]= (float)(-Math.sin(uLon)*offsetECEF[0] +
                Math.cos(uLon)*offsetECEF[1]);
        enu[1]= (float)(-Math.cos(uLon)*Math.sin(uLat)*offsetECEF[0] -
                Math.sin(uLon)*Math.sin(uLat)*offsetECEF[1] +
                Math.cos(uLat)*offsetECEF[2]);
        enu[2]= (float)(Math.cos(uLon)*Math.cos(uLat)*offsetECEF[0] +
                Math.sin(uLon)*Math.cos(uLat)*offsetECEF[1] +
                Math.sin(uLat)*offsetECEF[2]);
        return enu;
    }


}